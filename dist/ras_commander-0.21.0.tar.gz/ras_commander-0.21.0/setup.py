from setuptools import setup, find_packages

setup(
    name="ras_commander",
    version="0.21.0",  # Replace with your actual version
    packages=["ras_commander"],  # Explicitly include only the `ras_commander` package
)
